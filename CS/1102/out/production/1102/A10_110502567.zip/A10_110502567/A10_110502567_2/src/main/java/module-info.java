module com.example.a10_110502567_2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.a10_110502567_2 to javafx.fxml;
    exports com.example.a10_110502567_2;
}