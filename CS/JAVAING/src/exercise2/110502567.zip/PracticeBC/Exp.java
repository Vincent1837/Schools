package exercise2;

public abstract class Exp {
	public abstract boolean eval();
	public abstract String toSExp();
}