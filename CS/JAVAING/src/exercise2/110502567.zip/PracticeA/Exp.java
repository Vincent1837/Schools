package exercise2;

public abstract class Exp {
	public abstract int eval();
	public abstract String toSExp();
}