# compile
```
g++ -o test main.cpp hero.cpp battle.cpp monster.cpp yasuo.cpp kirito.cpp io.cpp anduin.cpp
```

# run
```
# 執行建議把 CMD 或 shell 開全螢幕
test.exe
```

# example
```
windows-example.exe # windows 環境執行(建議)
linux-example # linux 環境執行
mac-example # mac 環境執行
```