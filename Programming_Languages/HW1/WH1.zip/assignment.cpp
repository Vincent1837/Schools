#include <iostream>
using namespace std;

int main () {
	string a, b;
	while (cin >> a >> b) {
	cout << a << " loves " << b << endl;
	}
	return 0;
}
